str1 = input("Enter a word: ")
str2 = input("Enter a word: ")
str3 = input("Enter a word: ")
str4 = input("Enter a word: ")
str5 = input("Enter a word: ")

str6 = str1 + " " + str2 + " " + str3 + ' ' + str4 + ' ' + str5
print(str6)