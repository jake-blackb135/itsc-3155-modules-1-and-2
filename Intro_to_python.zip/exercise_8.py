list = []
num1 = int(input("Enter a number"))
list.append(num1)
num2 = int(input("Enter a number"))
if num2 not in list:
    list.append(num2)
num3 = int(input("Enter a number"))
if num3 not in list:
    list.append(num3)
num4 = int(input("Enter a number"))
if num4 not in list:
    list.append(num4)
num5 = int(input("Enter a number"))
if num5 not in list:
    list.append(num5)
num6 = int(input("Enter a number"))
if num6 not in list:
    list.append(num6)
num7 = int(input("Enter a number"))
if num7 not in list:
    list.append(num7)
num8 = int(input("Enter a number"))
if num8 not in list:
    list.append(num8)
num9 = int(input("Enter a number"))
if num9 not in list:
    list.append(num9)
num10 = int(input("Enter a number"))
if num10 not in list:
    list.append(num10)
print(list)